# Part 9: publishing this repository to GitHub

The repository is already initialised with one commit. To publish it:

## 1. Set your identity (the commit currently uses a placeholder)
```bash
git config user.name "Your Name"
git config user.email "your@email.com"
git commit --amend --reset-author --no-edit
```

## 2. Create an empty repo on GitHub
Go to https://github.com/new — name it `electricity-demand-forecasting`,
**do not** tick "Add a README" (one already exists).

## 3. Push
```bash
git remote add origin https://github.com/YOUR-USERNAME/electricity-demand-forecasting.git
git branch -M main
git push -u origin main
```

## Notes
* `data/raw/` and `outputs/` are git-ignored: the OPSD file is 125 MB, above
  GitHub's 100 MB limit. This is intentional and standard practice — the README
  documents how to regenerate everything from a fresh clone.
* If you want the figures visible on GitHub, either commit them deliberately:
  ```bash
  git add -f outputs/figures/*.png && git commit -m "Add result figures"
  ```
  or copy the key ones into `reports/figures/` (which is tracked).
* Verify a fresh clone runs:
  ```bash
  git clone <your-url> test-clone && cd test-clone
  pip install -r requirements.txt && pip install -e . && pytest
  ```
