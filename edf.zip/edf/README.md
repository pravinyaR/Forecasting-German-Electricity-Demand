# Forecasting German Electricity Demand

A reproducible time-series pipeline for modelling and forecasting German
electricity demand. Hourly load from [Open Power System Data][opsd] is cleaned,
aggregated to weekly/daily average load (GW), and forecast with a ladder of
models from simple benchmarks up to SARIMAX, feature-based ML, and an LSTM.

[opsd]: https://data.open-power-system-data.org/time_series/

## Project aim

Forecast weekly German electricity demand and compare the accuracy,
uncertainty, interpretability and complexity of different approaches. Research
questions:

1. How well do simple benchmarks forecast weekly demand?
2. Does SARIMAX improve on seasonal benchmarks?
3. Do temperature/holiday covariates improve accuracy?
4. Do feature-based or neural models justify their extra complexity?
5. Which model is most appropriate operationally?

## Data

Target: German actual load (`DE_load_actual_entsoe_transparency`) from the OPSD
`time_series_60min_singleindex.csv` (2020-10-06 release), converted MW → GW and
clipped to **2015-01-01 → end of file (Oct 2020)**. Target column: `load_gw`.

Optional covariates: `temp_mean`, `temp_min`, `temp_max`,
`heating_degree_days`, `cooling_degree_days`, `holiday_days`, `has_holiday`.

> Temperature is not known in advance. Using observed test-period temperature
> makes the SARIMAX forecast a **conditional / explanatory** forecast, not an
> operational one. Holidays are known ahead of time and are valid future
> covariates.

## Repository structure

```text
electricity-demand-forecasting/
├── README.md, requirements.txt, environment.yml, pyproject.toml, .gitignore
├── data/            raw / interim / processed   (git-ignored)
├── src/electricity_demand/
│   ├── config.py         paths, split, grid ranges, constants
│   ├── data.py           download, clean hourly load, aggregate, load processed
│   ├── features.py       temperature, calendar, holiday, lags/rolling, ADF/KPSS, STL
│   ├── evaluation.py     MAE, RMSE, MASE, Bias, interval coverage
│   ├── plotting.py       series, decomposition, ACF/PACF, forecasts, residuals
│   ├── pipeline.py       run_pipeline() end-to-end
│   └── models/           benchmarks, sarimax, feature_models, bayesian, neural
├── scripts/         download_data, make_features, run_pipeline, evaluate_models
├── notebooks/       01_eda, 02_benchmarks_sarima, ... (exploration + report figures)
├── outputs/         figures / forecasts / metrics / model_objects (git-ignored)
├── reports/         report.md + figures
└── tests/           test_benchmarks, test_evaluation, test_features
```

## Installation

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .                                       # makes `electricity_demand` importable
```

or with conda: `conda env create -f environment.yml && conda activate electricity-demand-forecasting`.

For Part 6 (LSTM) also `pip install tensorflow`.

## Reproducing the analysis

```bash
python scripts/download_data.py     # fetch raw OPSD 60-min CSV -> data/raw/
python scripts/make_features.py     # clean, aggregate, build weekly feature table
python scripts/run_pipeline.py      # fit models, evaluate, save outputs
python scripts/evaluate_models.py   # extra error-diagnostic figure

# optional / full analysis
python scripts/run_sarima_grid.py            # exhaustive 147-model AIC grid (resumable)
python scripts/run_sarima_grid.py --budget 240   # ...or run in time-boxed chunks
python scripts/tune_lstm.py                  # 16-config LSTM hyperparameter search
python scripts/train_lstm.py                 # train tuned LSTM + 2-year forecast
```

If you already have the raw CSV, drop it in `data/raw/time_series_60min_singleindex.csv`
and skip the first command.

Outputs produced:

```text
outputs/forecasts/all_forecasts.csv
outputs/metrics/model_comparison.csv
outputs/figures/forecast_comparison.png
outputs/figures/error_diagnostics.png
```

## Results (real data, 104-week test period)

| model | MAE | RMSE | MASE | Bias | vs seasonal naive |
|---|---|---|---|---|---|
| bayesian | 1.599 | 2.162 | **1.160** | +1.254 | −28.0% |
| feature_model (gradient boosting) | 1.903 | 2.580 | 1.380 | +1.383 | −14.1% |
| random_forest | 1.960 | 2.597 | 1.421 | +1.165 | −13.5% |
| seasonal_naive | 2.315 | 3.003 | 1.678 | +1.736 | — |
| sarimax_temp_holiday | 2.867 | 3.649 | 2.078 | +2.729 | +21.5% |
| sarimax_temp | 3.121 | 3.933 | 2.263 | +2.968 | +31.0% |
| sarima | 3.386 | 4.132 | 2.455 | +3.268 | +37.6% |
| naive | 3.780 | 4.457 | 2.741 | −0.882 | +48.4% |
| mean | 3.822 | 4.443 | 2.771 | +0.811 | +48.0% |
| lstm | 4.026 | 4.783 | 2.919 | −0.986 | +59.3% |
| drift | 4.633 | 5.527 | 3.359 | +1.655 | +84.0% |

Errors in GW. Selected SARIMA order: **(1,1,6)(1,1,1,52)**, AIC 302.4, chosen by an
exhaustive 147-model grid (p∈[0,6], d∈[0,2], q∈[0,6]); residuals pass Ljung-Box at all
tested lags (p > 0.94). The test window contains the COVID-19 demand collapse, which is
why almost every model shows positive bias. See `reports/report.docx` for full analysis.

## Models

* **Benchmarks** (`models/benchmarks.py`): mean, naive, seasonal-naive (s=52),
  drift. Seasonal-naive is the reference every model is compared against.
* **SARIMAX** (`models/sarimax.py`): `grid_search_sarima` selects `(p,d,q)` over
  p∈[0,6], d∈[0,2], q∈[0,6] plus a small seasonal grid by **AIC**; `fit_sarimax`
  fits a chosen order with optional exog; `forecast_sarimax_intervals` returns
  prediction intervals.
* **Feature-based** (`models/feature_models.py`): HistGradientBoosting /
  RandomForest on a leakage-safe lag/rolling/calendar/holiday/temperature table.
* **Bayesian** (`models/bayesian.py`, optional): BayesianRidge with posterior
  predictive intervals.
* **LSTM** (`models/neural.py`, optional): hourly seq-to-one / seq-to-seq, with
  train-only scaling; see the module docstring on the two-year-horizon caveat.

## Evaluation

Metrics: **MAE, RMSE, MASE, Bias** on a common test period (default final
**104 weeks**, a two-year hold-out). Do **not** use a random split — this is a
forecasting problem. Diagnostics: error plots, residual ACF, interval coverage,
performance around Christmas/New-Year and extreme-temperature weeks.

## Avoiding data leakage

* Lag/rolling features are built with `shift` (rolling is shifted by one before
  the window), so row `t` never sees `t` or later.
* Scalers/models are fit on the training portion only.
* Never scale the whole series before splitting; never select on the test set.
* Observed future temperature ⇒ label the forecast *conditional*.

## Testing

```bash
pytest
```

Covers: forecast lengths match the horizon, MASE = 0 for a perfect forecast,
lag features never use future values, feature table has no missing target.

## Report

`reports/report.md` holds the 6–8 page write-up (≤ 0.5 page references),
answering the six assignment questions and comparing every model against the
seasonal-naive benchmark with critical discussion, not just numbers.
