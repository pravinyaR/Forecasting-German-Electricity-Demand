// build_report.js -- generates reports/report.docx
// Run with:  node build_report.js   (from the repository root)
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType,
  ImageRun, Footer, PageNumber, LevelFormat, convertInchesToTwip,
} = require('docx');

const FONT = 'Times New Roman';
const BLACK = '000000';
const FIG = 'outputs/figures/';

const img = (f, w, h) => new Paragraph({
  alignment: AlignmentType.CENTER,
  children: [new ImageRun({ type: 'png', data: fs.readFileSync(FIG + f),
                            transformation: { width: w, height: h } })],
});
const cap = (t) => new Paragraph({
  alignment: AlignmentType.CENTER, spacing: { before: 40, after: 110 },
  children: [new TextRun({ text: t, italics: true, size: 18, color: BLACK, font: FONT })],
});
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 170, after: 75 },
  children: [new TextRun({ text: t, bold: true, size: 26, color: BLACK, font: FONT })] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 120, after: 55 },
  children: [new TextRun({ text: t, bold: true, size: 22, color: BLACK, font: FONT })] });
const p = (t) => new Paragraph({
  spacing: { after: 80, line: 240 }, alignment: AlignmentType.JUSTIFIED,
  children: [new TextRun({ text: t, size: 21, color: BLACK, font: FONT })],
});

// Harvard reference as a bullet. `parts` is a list of {t, i?} where i = italic
// (used for journal / book / conference titles, per Harvard convention).
const ref = (parts) => new Paragraph({
  numbering: { reference: 'refs', level: 0 },
  spacing: { after: 40, line: 200 },
  indent: { left: convertInchesToTwip(0.3), hanging: convertInchesToTwip(0.15) },
  children: parts.map(x => new TextRun({
    text: x.t, italics: !!x.i, size: 18, color: BLACK, font: FONT,
  })),
});

function makeTable(headers, rows, widths) {
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (text, o = {}) => new TableCell({
    width: { size: o.w, type: WidthType.DXA },
    shading: o.head ? { type: ShadingType.CLEAR, fill: 'F2F2F2' } : undefined,
    margins: { top: 40, bottom: 40, left: 70, right: 70 },
    children: [new Paragraph({
      alignment: o.head ? AlignmentType.CENTER : (o.num ? AlignmentType.RIGHT : AlignmentType.LEFT),
      children: [new TextRun({ text: String(text), bold: !!o.head, size: 18, color: BLACK, font: FONT })],
    })],
  });
  return new Table({
    columnWidths: widths,
    width: { size: total, type: WidthType.DXA },
    rows: [
      new TableRow({ tableHeader: true, children: headers.map((t, i) => cell(t, { head: true, w: widths[i] })) }),
      ...rows.map(r => new TableRow({ children: r.map((t, i) => cell(t, { w: widths[i], num: i > 0 })) })),
    ],
  });
}

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: FONT, size: 21, color: BLACK } },
      heading1: { run: { font: FONT, size: 26, bold: true, color: BLACK } },
      heading2: { run: { font: FONT, size: 22, bold: true, color: BLACK } },
    },
  },
  numbering: { config: [{
    reference: 'refs',
    levels: [{ level: 0, format: LevelFormat.BULLET, text: '\u2022',
               alignment: AlignmentType.LEFT,
               style: { paragraph: { indent: { left: convertInchesToTwip(0.3), hanging: convertInchesToTwip(0.15) } } } }],
  }] },
  sections: [{
    properties: { page: { margin: { top: 880, bottom: 880, left: 980, right: 980 } } },
    footers: { default: new Footer({ children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: ['Page ', PageNumber.CURRENT, ' of ', PageNumber.TOTAL_PAGES], size: 17, color: BLACK, font: FONT })],
    })] }) },
    children: [

// ===== TITLE =====
new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 },
  children: [new TextRun({ text: 'Forecasting German Electricity Demand:', bold: true, size: 32, color: BLACK, font: FONT })] }),
new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 180 },
  children: [new TextRun({ text: 'A Comparative Study of Benchmark, SARIMAX, Feature-Based and Neural Models', bold: true, size: 26, color: BLACK, font: FONT })] }),
new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 },
  children: [new TextRun({ text: '[STUDENT NAME]   [STUDENT ID]', bold: true, size: 22, color: BLACK, font: FONT })] }),
new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 220 },
  children: [new TextRun({ text: '[MODULE CODE], [MODULE TITLE].  July 2026', size: 20, color: BLACK, font: FONT })] }),

// ===== 1 =====
h1('1. Introduction'),
p('Electricity demand forecasting supports generation scheduling, reserve procurement and market bidding. The costs of getting it wrong are asymmetric. Under-forecasting risks reserve shortfalls, while over-forecasting commits capacity that is not needed and is expensive to hold. This study models German electricity demand using data from Open Power System Data (OPSD) and compares forecasting approaches of increasing complexity, from simple benchmarks through to a recurrent neural network.'),
p('The question is not only which model gives the lowest error, but whether the extra complexity earns its place. Every model is therefore compared against a seasonal naive benchmark over a two-year (104-week) horizon. That horizon turns out to matter a great deal, because the test period from October 2018 to October 2020 contains the COVID-19 demand collapse, a structural break that the training data does not contain. This proved to be the most informative aspect of the study, since it separates models that fit history well from models that forecast well.'),

// ===== 2 =====
h1('2. Data and Preprocessing'),
p('The target series is German actual load (DE_load_actual_entsoe_transparency) from the OPSD 60-minute single-index file, 2020-10-06 release (Open Power System Data, 2020). The preprocessing code is in src/electricity_demand/data.py.'),
p('Load was converted from MW to GW, and the UTC timestamps were converted to Europe/Berlin local time before aggregation so that the bins line up with the German calendar and with the Berlin temperature covariate. Observations from 1 January 2015 to the end of the file (1 October 2020) were retained, giving 50,402 hourly values. The autumn clock change duplicates one local hour each year, so those duplicates were averaged, and six missing values were filled by time interpolation. Hourly load was then aggregated to daily and weekly means, giving 2,101 daily and 301 weekly observations. Hourly load averages 55.49 GW with a range of 31.3 to 77.5 GW, while weekly average load, the main modelling target, ranges from 46.5 to 63.6 GW.'),
p('Berlin (52.52\u00B0N, 13.41\u00B0E) was used as a representative location for German temperature, with data from the Open-Meteo archive API. Five weekly temperature features were derived: mean, minimum and maximum temperature, together with heating degree days (base 15.5\u00B0C) and cooling degree days (base 22\u00B0C). German public holidays were encoded as holiday_days, a count per week, and has_holiday, a binary flag. The difference between the two kinds of covariate matters and is taken up in Section 8. Holidays are known well in advance, whereas temperature is not.'),

// ===== 3 =====
h1('3. Exploratory Analysis'),
img('eda_weekly.png', 490, 174),
cap('Figure 1: Weekly average German electricity load, 2015 to 2020. Annual seasonality dominates, and the sharp downward spikes are the Christmas and New Year weeks. The decline from March 2020 is the COVID-19 demand collapse.'),
p('Figure 1 shows an annual cycle with winter peaks near 63 GW and summer troughs near 48 GW, which follows from heating, lighting and industrial activity. Sharp downward spikes appear at the turn of each year, caused by the Christmas and New Year shutdown. From March 2020 the level falls noticeably as pandemic restrictions reduced industrial and commercial activity. Across 2015 to 2019 there is no strong long-term trend.'),
img('eda_stl.png', 340, 246),
cap('Figure 2: STL decomposition of weekly load (period 52). The seasonal component is large and stable, and the trend component is comparatively flat until the 2020 downturn.'),
p('The STL decomposition in Figure 2 supports this reading. The seasonal component is large and regular, while the trend component stays fairly flat until it drops in 2020. The structure worth modelling here is seasonal rather than trending.'),
h2('3.1 Stationarity testing'),
p('Augmented Dickey-Fuller (ADF) and KPSS tests were run at several differencing levels using statsmodels (Seabold and Perktold, 2010). The two tests have opposite null hypotheses. ADF tests for a unit root, so a low p-value points to stationarity, while KPSS tests for stationarity, so a low p-value points the other way. Agreement between them is more convincing than either result on its own.'),
makeTable(['Series', 'ADF p', 'ADF verdict', 'KPSS p', 'KPSS verdict'],
  [['Level', '0.0012', 'Stationary', '0.100', 'Stationary'],
   ['First difference', '0.0000', 'Stationary', '0.100', 'Stationary'],
   ['Seasonal difference (52)', '0.0004', 'Stationary', '0.010', 'Non-stationary'],
   ['Seasonal + first difference', '0.0000', 'Stationary', '0.100', 'Stationary']],
  [2100, 1000, 1600, 1000, 1700]),
cap('Table 1: Stationarity tests on the weekly series. Both tests agree that the level series is already stationary.'),
p('The result is initially surprising. Both tests agree that the level series is already stationary, since ADF gives p = 0.0012 and rejects the unit root while KPSS gives p = 0.10 and fails to reject stationarity. The non-stationarity in this series is therefore seasonal rather than trend-driven. The annual cycle is strong but mean-reverting, which is what Figure 2 shows. This supports the differencing strategy used in Section 4, namely a low non-seasonal order combined with one seasonal difference at lag 52.'),
img('eda_acf_pacf.png', 370, 233),
cap('Figure 3: ACF and PACF of weekly load. Slow decay with pronounced peaks at multiples of 52 weeks confirms annual seasonality.'),
p('The ACF in Figure 3 decays slowly and has clear peaks at multiples of 52 weeks. This confirms the annual period and supports a seasonal period of s = 52 in the SARIMA specification.'),

// ===== 4 =====
h1('4. Forecasting Methods'),
h2('4.1 Benchmark models'),
p('Four benchmarks were implemented. The mean forecast sets every future value to the training mean, the naive forecast sets every future value to the last observation, the seasonal naive forecast sets each week equal to the same week one year earlier, and the drift forecast extends a line drawn through the first and last training points. For a series with dominant annual seasonality and negligible trend, seasonal naive is the appropriate reference model, and it is used as the comparison point throughout (Hyndman and Athanasopoulos, 2021).'),
h2('4.2 SARIMA and SARIMAX'),
p('A seasonal ARIMA model of order (p,d,q)(P,D,Q)s was fitted using statsmodels. An exhaustive grid search was run over p in [0,6], d in [0,2] and q in [0,6], which is 147 combinations, with the seasonal component held at (1,1,1,52). All 147 models converged. Selection was by Akaike Information Criterion (AIC), which balances fit against parameter count.'),
p('Holding the seasonal order fixed was a compromise. Each seasonal fit takes several seconds, and searching the seasonal orders as well would have multiplied the grid for little expected benefit, given that the EDA finds exactly one annual cycle and the stationarity tests point to one seasonal difference. The full grid results are saved in outputs/metrics/sarima_aic_full.csv.'),
p('SARIMAX extends the model by admitting exogenous regressors. Temperature and holiday features were passed through the exog argument, producing the covariate models evaluated in Section 8.'),
h2('4.3 Feature-based models'),
p('Three regression models were fitted: histogram gradient boosting, random forest and Bayesian ridge. The supervised learning table contains lag features at 1, 2, 3, 4 and 52 weeks, rolling mean and standard deviation over 4, 8 and 52-week windows, calendar features covering month, week of year, quarter and Fourier terms for the annual cycle, holiday counts and the five temperature features. Bayesian ridge also yields posterior predictive intervals.'),
p('All lag and rolling features were built with pandas shift, so that a row at time t contains only information available before t, and rolling statistics were computed on the shifted series. Section 8 covers this in more detail.'),
h2('4.4 LSTM: literature and design'),
p('Long Short-Term Memory networks (Hochreiter and Schmidhuber, 1997) use gated memory cells to address the vanishing gradient problem in recurrent networks, which allows them to learn long-range temporal dependencies. Their application to electricity load forecasting is well established. Kong et al. (2019) applied LSTMs to residential short-term load forecasting and reported improvements over conventional methods at the household level, where demand is volatile. Marino, Amarasinghe and Manic (2016) compared standard and sequence-to-sequence LSTM architectures for building energy load and found the sequence-to-sequence version considerably more stable for multi-step prediction. Bouktif et al. (2018) worked on French metropolitan demand and argued that careful feature selection and hyperparameter optimisation drove performance rather than depth alone.'),
p('One caveat runs through this literature, and it concerns horizon. The reported successes are almost all short-term, typically hours to days ahead. Makridakis, Spiliotis and Assimakopoulos (2018) compared statistical and machine learning methods across a large set of series and found that statistical methods were often better on longer horizons, particularly where data are limited. The task here is two years of hourly data, or 17,472 steps ahead, which sits well outside the range in which LSTMs are usually reported to do well. This shaped the architecture rather than being discovered afterwards.'),
p('A direct multi-step design was therefore used. The network predicts a 168-hour block in a single forward pass from a 336-hour lookback, and this block is rolled forward 104 times to cover the horizon. An hour-by-hour recursive rollout would need 17,472 sequential predictions and would compound error at every one of them, whereas the block design compounds error 104 times instead. Training windows were strided by 6 to keep CPU training feasible, and the MinMax scaler was fitted on training hours only.'),
p('Hyperparameters and layer design were tuned by grid search over units {32, 64}, layers {1, 2}, lookback {168, 336} and dropout {0.0, 0.2}, giving 16 configurations. Each was selected on validation loss computed from the final 10% of training windows, and the test period was not used at any point during tuning.'),
makeTable(['Units', 'Layers', 'Lookback', 'Dropout', 'Val. loss'],
  [['64', '2', '336', '0.0', '0.0638'],
   ['64', '2', '168', '0.0', '0.0638'],
   ['64', '2', '168', '0.2', '0.0639'],
   ['64', '1', '168', '0.2', '0.0689'],
   ['32', '1', '336', '0.2', '0.0978']],
  [1300, 1300, 1500, 1300, 1600]),
cap('Table 2: LSTM tuning, showing the best four and the worst of 16 configurations. Full results are in outputs/metrics/lstm_tuning.csv.'),
p('The search gives a clear signal on capacity and depth, since 64 units outperform 32 and two layers outperform one. Lookback and dropout make little difference, as the top four configurations are separated by less than 0.001.'),

// ===== 5 =====
h1('5. Evaluation Design'),
p('All models were evaluated on an identical test period, the final 104 weeks from 14 October 2018 to 4 October 2020, with training on the preceding 145 weeks from 3 January 2016 to 7 October 2018. The window begins in 2016 because the 52-week lag features need a full year of burn-in, and using a common window ensures every model is compared on equal terms. No random splitting was used, since this is a forecasting problem in which temporal order carries the information.'),
p('Four metrics are reported. MAE and RMSE measure average and squared-error magnitude, with RMSE penalising large errors more heavily. MASE scales absolute error by the in-sample seasonal naive error, so a value below 1 means the model beats seasonal naive on the training scale. Bias, the mean signed error, is included because systematic directional error proves to be the dominant failure mode here. Prediction interval coverage at the 80% nominal level is reported for the two probabilistic models.'),

// ===== 6 =====
h1('6. Results'),
h2('6.1 SARIMA order selection'),
p('The exhaustive grid selected SARIMA(1,1,6)(1,1,1,52) with AIC = 302.4. An earlier focused search over a small candidate set had chosen SARIMA(0,0,1)(1,1,1,52) with AIC = 321.9, so the full grid improved AIC by roughly 19 points and was worthwhile on its own terms. The selected model uses d = 1 even though the level series tests as stationary, while the seasonal difference D = 1 at s = 52 agrees with the diagnostics in Section 3.'),
img('sarima_residuals.png', 335, 222),
cap('Figure 4: SARIMA(1,1,6)(1,1,1,52) residual diagnostics, showing residuals over time, their distribution, the ACF and a normal Q-Q plot.'),
p('The residual diagnostics in Figure 4 indicate an adequate fit. The residual ACF shows no significant autocorrelation, and the Ljung-Box test agrees (Ljung and Box, 1978), giving p = 0.980 at lag 10, p = 0.988 at lag 20 and p = 0.946 at lag 52, so the null hypothesis of no residual autocorrelation cannot be rejected at any lag tested. The residuals are close to normal, with mild tail deviation in the Q-Q plot attributable to the Christmas and New Year weeks. The in-sample fit is sound, which makes the out-of-sample results that follow more interesting.'),
h2('6.2 Model comparison'),
makeTable(['Model', 'MAE', 'RMSE', 'MASE', 'Bias', 'vs SN'],
  [['Bayesian ridge', '1.599', '2.162', '1.160', '+1.254', '\u221228.0%'],
   ['Gradient boosting', '1.903', '2.580', '1.380', '+1.383', '\u221214.1%'],
   ['Random forest', '1.960', '2.597', '1.421', '+1.165', '\u221213.5%'],
   ['Seasonal naive', '2.315', '3.003', '1.678', '+1.736', ''],
   ['SARIMAX (temp+holiday)', '2.867', '3.649', '2.078', '+2.729', '+21.5%'],
   ['SARIMAX (temp)', '3.121', '3.933', '2.263', '+2.968', '+31.0%'],
   ['SARIMA', '3.386', '4.132', '2.455', '+3.268', '+37.6%'],
   ['Naive', '3.780', '4.457', '2.741', '\u22120.882', '+48.4%'],
   ['Mean', '3.822', '4.443', '2.771', '+0.811', '+48.0%'],
   ['LSTM', '4.026', '4.783', '2.919', '\u22120.986', '+59.3%'],
   ['Drift', '4.633', '5.527', '3.359', '+1.655', '+84.0%']],
  [2600, 1080, 1080, 1080, 1180, 1180]),
cap('Table 3: Model comparison on the common 104-week test period, ranked by MASE. Errors are in GW, and the final column gives the RMSE change relative to seasonal naive, where negative is better.'),
img('forecast_comparison.png', 470, 212),
cap('Figure 5: All model forecasts against actual demand over the two-year test horizon. Nearly every model sits above the actual series through 2020.'),
p('Only three models beat seasonal naive, and all three are lag-based: Bayesian ridge with RMSE 28.0% lower, gradient boosting at 14.1% lower and random forest at 13.5% lower. Every SARIMA variant performs worse than the benchmark despite excellent in-sample diagnostics. Almost every model over-forecasts, with bias between 0.8 and 3.3 GW.'),

// ===== 7 =====
h1('7. Error Analysis'),
p('The pervasive positive bias in Table 3 is not coincidental, and it has a single identifiable cause. The test window contains the COVID-19 demand collapse from March 2020, a structural break entirely absent from the 2016 to 2018 training data. Every model trained on pre-pandemic data projects pre-pandemic demand levels and therefore over-forecasts the final months of the horizon. Figure 5 shows this directly, with the actual series dropping away from the forecast envelope in 2020 and never returning.'),
p('This explains why the models that lean most heavily on learned structure fare worst. SARIMA propagates a rigid seasonal pattern estimated from pre-COVID years and has no mechanism to revise the level, which leaves it with the highest bias at +3.27 GW. The lag-based feature models perform best because their most informative predictors are recent lags and rolling means, which partially track the new and lower level as the horizon advances. Their advantage is adaptivity rather than sophistication.'),
img('sarimax_best_interval.png', 470, 212),
cap('Figure 6: Best SARIMAX forecast, using temperature and holiday covariates, with an 80% prediction interval. The realised 2020 demand falls entirely below the interval.'),
p('The consequences for uncertainty quantification are severe. The best SARIMAX achieves only 40.4% empirical coverage against a nominal 80% level, as Figure 6 shows. The interval is far too narrow because it reflects only estimated parameter and innovation uncertainty, not the possibility of a regime change. Bayesian ridge attains 100% coverage, but this is not a success either, since its intervals are so wide as to be uninformative. Both failures show that prediction intervals quantify the uncertainty a model knows about rather than the uncertainty that exists.'),
h2('7.1 LSTM behaviour'),
img('lstm_first_two_weeks.png', 490, 160),
cap('Figure 7: LSTM hourly forecast over the first two weeks of the horizon. The daily cycle and the weekday and weekend structure are captured, with some amplitude compression.'),
p('The LSTM deserves separate comment, because it did not behave as anticipated. Over a 17,472-step rollout, a recursive network would be expected to drift toward the series mean and lose amplitude. That did not happen. The forecast retains its daily amplitude throughout, with a forecast standard deviation of 6.3 GW in the first week and 7.2 GW in the final week, and a range spanning 38 to 72 GW across the entire two years. Figure 7 shows the daily cycle and the weekday and weekend structure reproduced faithfully at the start of the horizon.'),
p('Error growth is nonetheless evident, as theory predicts. Hourly RMSE rises from 9.8 GW in the first 16 weeks to 15.6 GW by weeks 48 to 64, before partially recovering. The pattern is that the LSTM tracks shape well and level poorly. It also records the smallest absolute bias of any model at the hourly resolution, at +0.07 GW. Its tendency toward mean reversion over a long rollout, ordinarily a defect, happened to hedge against the COVID level shift. This is luck rather than skill, since the model had no knowledge of the pandemic, but it does illustrate that a weakness under normal conditions can become a strength under a structural break.'),

// ===== 8 =====
h1('8. Discussion: Responses to Assignment Questions'),
h2('Q1. Compare all models against the seasonal naive benchmark. Which, if any, provide a meaningful improvement?'),
p('Three models improve on seasonal naive. Bayesian ridge reduces RMSE from 3.003 to 2.162, a 28.0% reduction, with MASE falling from 1.678 to 1.160. Gradient boosting achieves a 14.1% reduction and random forest 13.5%. Every other model, including all the SARIMA variants and the LSTM, performs worse than the benchmark.'),
p('Whether a 28% reduction counts as meaningful requires care. It comes from a single test window containing an exceptional event, so it partly measures a model\'s capacity to adapt to COVID rather than general forecasting skill. Every model has a MASE above 1.0, which means none of them forecast the test period as accurately as seasonal naive forecast the training period. Rolling-origin evaluation across multiple windows would be needed before claiming a durable advantage.'),
h2('Q2. Explain how you avoided data leakage when creating temperature lag features.'),
p('Four mechanisms were used. All lag and rolling features were constructed with pandas shift, so a row at time t contains only values from strictly before t, and rolling statistics were computed on the already-shifted series, which ensures the window for row t ends at t-1 and never includes the current value. The train and test split was strictly chronological with no random splitting. The MinMax scaler for the LSTM was fitted on training data only and then applied to the test period, never fitted on the full series. LSTM hyperparameter selection used a validation split drawn from the end of the training windows, and the test set was never consulted during tuning.'),
p('These properties are enforced by automated tests in tests/test_features.py, which verify that lag features never equal the current value and that rolling means match a manually shifted calculation. One caveat should be stated directly. The temperature covariate itself uses observed test-period values, which is not leakage in the feature-construction sense but does make the SARIMAX forecast conditional rather than operational. Q4 addresses this.'),
h2('Q3. For the SARIMAX model, justify the chosen differencing orders and seasonal period.'),
p('The seasonal period s = 52 follows directly from the data, since weekly observations with an annual cycle give 52 periods per year. The ACF in Figure 3 shows pronounced peaks at multiples of 52, and the STL in Figure 2 isolates a large and stable annual component.'),
p('The seasonal differencing order D = 1 is justified because the seasonal structure is the dominant non-stationary feature. Table 1 shows that the level series is already stationary under both ADF and KPSS, so the differencing required is seasonal rather than trend-removing.'),
p('The non-seasonal order d = 1 was selected by the AIC grid search over d in [0,2]. This is worth questioning, because the stationarity tests suggest d = 0 would suffice. AIC nevertheless favoured d = 1, most likely because the additional difference helps accommodate the slow level movements visible from 2019 onwards. Here an automatic criterion and the diagnostic evidence point in slightly different directions. In practice the difference is small, since SARIMA(0,0,1) and SARIMA(1,1,6) give test RMSE of 3.832 and 3.881 respectively.'),
h2('Q4. Evaluate whether temperature and holiday covariates improve forecast accuracy. Are these covariates known at the forecast origin?'),
makeTable(['Covariates', 'AIC', 'MAE', 'RMSE', 'MASE'],
  [['None (SARIMA)', '139.1', '3.386', '4.132', '2.455'],
   ['Temperature only', '133.8', '3.121', '3.933', '2.263'],
   ['Holiday only', '124.3', '3.424', '4.140', '2.483'],
   ['Temperature + holiday', '129.5', '2.867', '3.649', '2.078']],
  [2400, 1200, 1200, 1200, 1200]),
cap('Table 4: Covariate ablation on the SARIMAX(1,1,6)(1,1,1,52) specification.'),
p('Temperature improves accuracy materially. RMSE falls from 4.132 to 3.933, a reduction of 4.8%, and MASE falls from 2.455 to 2.263. Combining temperature with holidays is better still, reducing RMSE to 3.649, an improvement of 11.7% over no covariates. The fitted coefficients are physically sensible, since heating degree days carries a positive coefficient of +0.063, so colder weeks raise demand, which is consistent with electric heating and lighting load.'),
p('Holidays alone do not improve forecast accuracy, giving RMSE of 4.140 against 4.132 without covariates, despite achieving the best AIC of all four specifications at 124.3. This divergence between an in-sample criterion and out-of-sample accuracy recurs throughout the study and is discussed in Section 10. The likely explanation is that the seasonal component already absorbs most recurring holiday effects, since German public holidays fall in nearly the same week each year.'),
p('The two covariates differ fundamentally in availability. Holidays are deterministic and known years ahead, so they are legitimate future covariates for operational use. Temperature is not known in advance. This study uses realised test-period temperature, which makes every temperature-based forecast here explanatory or conditional rather than operational. An operational system would have to substitute a weather forecast, whose own error would degrade accuracy, and beyond roughly two weeks no meaningful weather forecast exists. The temperature-driven gains in Table 4 should therefore be read as an upper bound that is unattainable in deployment at a two-year horizon.'),
h2('Q5. Compare the interpretability and complexity of SARIMAX, feature-based, and neural network models.'),
makeTable(['Criterion', 'SARIMAX', 'Feature-based', 'LSTM'],
  [['Parameters', 'about 10', '10 to 500 trees', 'about 90,000'],
   ['Fit time', 'seconds to minutes', 'seconds', 'about 4 minutes (CPU)'],
   ['Interpretability', 'High', 'Medium', 'Low'],
   ['Uncertainty', 'Native intervals', 'Bayesian variant only', 'None natively'],
   ['Test RMSE (GW)', '3.649', '2.162', '4.783']],
  [1900, 1700, 1800, 1800]),
cap('Table 5: Interpretability and complexity comparison.'),
p('SARIMAX is the most interpretable. It has roughly ten parameters with direct statistical meaning, exogenous coefficients that read as physical effects, and native prediction intervals derived from an explicit probabilistic model. Its structure is also its limitation, since the assumed form cannot adapt to a regime change.'),
p('Feature-based models occupy the middle ground. Individual trees are opaque, but feature importances identify which lags and covariates drive predictions, and the Bayesian ridge variant provides coefficients and posterior intervals while achieving the best accuracy here. They are cheap to fit and to retrain.'),
p('The LSTM is the least interpretable, with roughly 90,000 parameters that carry no individual meaning, no native uncertainty quantification and the longest training time. The most complex model produced the second worst RMSE. Complexity was counterproductive at this horizon and data volume, which echoes the caution raised by Makridakis, Spiliotis and Assimakopoulos (2018).'),
h2('Q6. Recommend one model for operational use and justify your choice.'),
p('The recommendation is the feature-based gradient boosting model rather than the Bayesian ridge that tops Table 3, and the reasoning turns on all four criteria rather than accuracy alone.'),
p('On accuracy, gradient boosting reduces RMSE by 14.1% relative to seasonal naive. Bayesian ridge is better at 28.0%, but its advantage rests on a linear structure that happened to extrapolate favourably through an unprecedented event, and its 100% coverage means its intervals are too wide to guide decisions, which indicates poor calibration rather than genuine reliability. On uncertainty, no model performed well, and SARIMAX at 40.4% coverage is materially overconfident, so an operational deployment should derive intervals empirically from rolling-origin backtest residuals rather than trusting any model\'s analytic intervals. On interpretability, gradient boosting supports feature importance analysis, which suffices for operational scrutiny even though it is less transparent than SARIMAX. On maintenance the case is strongest, since it retrains in seconds, requires no order re-selection unlike SARIMA with its 147-model grid, and needs no GPU or deep learning stack. Given that demand regimes shift, the ability to retrain frequently and cheaply matters more than a single window\'s accuracy.'),
p('This recommendation is specific to the long horizon set here. For day-ahead or week-ahead forecasting it would likely change, given the LSTM\'s strong performance early in the horizon shown in Figure 7 and the availability of usable weather forecasts at those ranges.'),

// ===== 9 =====
h1('9. Limitations'),
p('All conclusions rest on one 104-week period dominated by COVID-19. Rolling-origin evaluation across several windows would be needed before generalising, since the ranking in Table 3 may reflect which models coped with one exceptional event rather than which forecast well in general. The temperature results use realised temperature and are not operationally attainable at this horizon.'),
p('The (p,d,q) grid was exhaustive as specified, but the seasonal orders were fixed at (1,1,1,52) for computational reasons rather than searched. The grid also ran on the full weekly series with 197 training weeks, while the final comparison uses the feature-table window of 145 weeks required by the 52-week lags. The selected order was carried across, and re-running the grid on the shorter window could select a different one.'),
p('LSTM training was CPU-bound, limited to 10 epochs with strided windows, and used load history alone. A larger budget, together with temperature and calendar features as additional input channels, would give the LSTM a fairer test. Berlin stands in for the whole of Germany, which ignores regional climate variation. No COVID intervention variable was included, since adding one would improve the fit but would rely on hindsight unavailable at the forecast origin.'),

// ===== 10 =====
h1('10. Conclusion'),
p('This study forecast German electricity demand over a demanding two-year horizon using models ranging from simple benchmarks to a tuned LSTM. Weekly demand proved strongly seasonal with negligible trend, and both ADF and KPSS agreed that the level series was already stationary, so the non-stationarity was seasonal. That shaped the SARIMA specification. An exhaustive 147-model AIC grid selected SARIMA(1,1,6)(1,1,1,52), whose residuals were indistinguishable from white noise, with Ljung-Box p above 0.94 at every lag tested.'),
p('Despite that sound in-sample fit, only three models, all of them lag-based, beat the seasonal naive benchmark out of sample. The dominant reason is the COVID-19 structural break, which caused nearly every model to over-forecast and cut the best SARIMAX interval coverage to 40.4% against a nominal 80%.'),
p('A pattern runs through the results, in that in-sample selection criteria did not track out-of-sample performance. The full-grid winner (1,1,6) improved AIC by 19 points over the focused-search pick yet forecast marginally worse. Holiday covariates achieved the best AIC of any specification while failing to improve accuracy. The tuned LSTM improved validation loss by 43%, from 0.0438 to 0.0251, yet worsened test RMSE by 18%, from 12.65 to 14.97 GW. AIC and validation loss both measure one-step-ahead or one-block-ahead fit, whereas the task is a 104-week rollout across a regime the training data never contained.'),
p('For operational use, gradient boosting is recommended on the balance of accuracy, interpretability and, decisively, maintainability. The broader conclusion is that model complexity delivered no benefit here. The most complex model was among the worst, and the winning models won through adaptivity rather than sophistication. Future work should prioritise rolling-origin evaluation, regime-aware or intervention models, probabilistic forecasts calibrated against backtest residuals rather than model-analytic intervals, and a shorter horizon with covariates supplied as additional input channels for a fair assessment of neural methods.'),

// ===== REFERENCES (Harvard) =====
h1('References'),
ref([{ t: 'Bouktif, S., Fiaz, A., Ouni, A. and Serhani, M.A. (2018) \u2018Optimal deep learning LSTM model for electric load forecasting using feature selection and genetic algorithm\u2019, ' },
     { t: 'Energies', i: true }, { t: ', 11(7), 1636.' }]),
ref([{ t: 'Hochreiter, S. and Schmidhuber, J. (1997) \u2018Long short-term memory\u2019, ' },
     { t: 'Neural Computation', i: true }, { t: ', 9(8), pp. 1735-1780.' }]),
ref([{ t: 'Hyndman, R.J. and Athanasopoulos, G. (2021) ' },
     { t: 'Forecasting: Principles and Practice', i: true }, { t: '. 3rd edn. Melbourne: OTexts.' }]),
ref([{ t: 'Kong, W., Dong, Z.Y., Jia, Y., Hill, D.J., Xu, Y. and Zhang, Y. (2019) \u2018Short-term residential load forecasting based on LSTM recurrent neural network\u2019, ' },
     { t: 'IEEE Transactions on Smart Grid', i: true }, { t: ', 10(1), pp. 841-851.' }]),
ref([{ t: 'Ljung, G.M. and Box, G.E.P. (1978) \u2018On a measure of lack of fit in time series models\u2019, ' },
     { t: 'Biometrika', i: true }, { t: ', 65(2), pp. 297-303.' }]),
ref([{ t: 'Makridakis, S., Spiliotis, E. and Assimakopoulos, V. (2018) \u2018Statistical and machine learning forecasting methods: concerns and ways forward\u2019, ' },
     { t: 'PLoS ONE', i: true }, { t: ', 13(3), e0194889.' }]),
ref([{ t: 'Marino, D.L., Amarasinghe, K. and Manic, M. (2016) \u2018Building energy load forecasting using deep neural networks\u2019, ' },
     { t: 'IECON 2016: 42nd Annual Conference of the IEEE Industrial Electronics Society', i: true },
     { t: '. Florence, Italy, 23-26 October. Piscataway, NJ: IEEE, pp. 7046-7051.' }]),
ref([{ t: 'Open Power System Data (2020) ' }, { t: 'Time series data package', i: true },
     { t: ', version 2020-10-06. Available at: https://data.open-power-system-data.org/time_series/ (Accessed: 15 July 2026).' }]),
ref([{ t: 'Seabold, S. and Perktold, J. (2010) \u2018Statsmodels: econometric and statistical modeling with Python\u2019, ' },
     { t: 'Proceedings of the 9th Python in Science Conference', i: true },
     { t: '. Austin, TX, 28 June-3 July, pp. 92-96.' }]),

    ],
  }],
});

Packer.toBuffer(doc).then(b => { fs.writeFileSync('reports/report.docx', b); console.log('written', b.length, 'bytes'); });
